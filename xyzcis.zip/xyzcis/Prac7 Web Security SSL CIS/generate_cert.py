from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from datetime import datetime, timedelta, timezone
import ipaddress

# Generate private key
key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048
)

# Certificate information
name = x509.Name([
    x509.NameAttribute(NameOID.COMMON_NAME, "localhost")
])

# Create certificate
cert = (
    x509.CertificateBuilder()
    .subject_name(name)
    .issuer_name(name)
    .public_key(key.public_key())
    .serial_number(x509.random_serial_number())
    .not_valid_before(datetime.now(timezone.utc))
    .not_valid_after(datetime.now(timezone.utc) + timedelta(days=365))
    .add_extension(
        x509.SubjectAlternativeName([
            x509.DNSName("localhost"),
            x509.IPAddress(ipaddress.ip_address("127.0.0.1"))
        ]),
        critical=False
    )
    .sign(key, hashes.SHA256())
)

# Save private key
with open("key.pem", "wb") as f:
    f.write(key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()
    ))

# Save certificate
with open("cert.pem", "wb") as f:
    f.write(cert.public_bytes(serialization.Encoding.PEM))

print("SSL Certificate and Private Key Generated Successfully!")





# STEP 1: Create a project folder on Desktop
# Folder name: Prac7 Web Security SSL CIS

# STEP 2: Open the project folder in VS Code

# STEP 3: Create three Python files:
# generate_cert.py
# ssl_server.py
# ssl_client.py

# STEP 4: Write certificate-generation code in generate_cert.py
# Save the file using Ctrl + S

# STEP 5: Write SSL server code in ssl_server.py
# Save the file using Ctrl + S

# STEP 6: Write SSL client code in ssl_client.py
# Save the file using Ctrl + S

# STEP 7: Open Command Prompt
# Press Win + R, type cmd and press Enter

# STEP 8: Navigate to the project folder
# Command:
# cd "C:\Users\admin\Desktop\Prac7 Web Security SSL CIS"

# STEP 9: Install the required cryptography library
# Command:
# python -m pip install cryptography

# STEP 10: Generate SSL certificate and private key
# Command:
# python generate_cert.py

# STEP 11: Check that two files are generated:
# dir ----command in cmd
# cert.pem  - SSL Certificate
# key.pem   - Private Key

# STEP 12: Open the first CMD window and start the SSL server
# Command:
# python ssl_server.py

# STEP 13: Wait until the server starts listening on port 8443
# Do not close the first CMD window

# STEP 14: Open a second CMD window

# STEP 15: Navigate to the same project folder
# Command:
# cd "C:\Users\admin\Desktop\Prac7 Web Security SSL CIS"

# STEP 16: Run the SSL client
# Command:
# python ssl_client.py

# STEP 17: Client establishes a secure TLS connection with the server

# STEP 18: Client sends a message to the server

# STEP 19: Server receives the message and sends a response

# STEP 20: Observe the output in both CMD windows

# STEP 21: SSL Server-Client communication is completed
