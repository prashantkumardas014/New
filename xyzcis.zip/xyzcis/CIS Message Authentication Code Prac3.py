# Message Authentication Code (MAC) using HMAC-SHA256
import hmac
import hashlib
import base64

# function to generate MAC
def generate_mac(message, key):
    h = hmac.new(key.encode(), message.encode(), hashlib.sha256)
    return base64.b64encode(h.digest()).decode()

# function to verify MAC
def verify_mac(message, key, received_mac):
    new_mac = generate_mac(message, key)
    return new_mac == received_mac

# main
key     = input("Enter key: ")
message = input("Enter message: ")

# generate MAC
mac = generate_mac(message, key)
print("Generated MAC:", mac)

# verify MAC
is_verified = verify_mac(message, key, mac)
print("MAC Verified:", is_verified)
