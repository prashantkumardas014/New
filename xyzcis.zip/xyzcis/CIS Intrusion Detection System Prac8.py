# Simple Intrusion Detection System (IDS)

# Function to check packets
def analyze_packet(src_ip, payload):
    # Rule 1: Block a specific IP
    if src_ip == "192.168.1.100":
        print(f"ALERT: Blacklisted IP detected -> {src_ip}")

    # Rule 2: Detect SQL injection
    if "DROP TABLE" in payload:
        print(f"ALERT: SQL Injection attempt detected in payload -> {payload}")

    # Rule 3: Detect port scan
    if "nmap" in payload.lower():
        print(f"ALERT: Port scanning activity detected -> {payload}")


# Main
print("Starting Simple IDS...")

# Simulated traffic (IP, Payload)
traffic = [
    ["192.168.1.10", "Normal traffic"],
    ["192.168.1.100", "Hello server"],           # Blacklisted IP
    ["10.0.0.20", "User tried DROP TABLE"],      # SQL Injection
    ["172.16.0.5", "Running nmap scan..."],      # Port Scan
]

# Analyze each "packet"
for packet in traffic:
    analyze_packet(packet[0], packet[1])

print("IDS Monitoring Completed.")
