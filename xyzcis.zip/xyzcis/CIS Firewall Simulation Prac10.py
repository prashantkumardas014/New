# Firewall Simulation

# Step 1: Packet class
class Packet:
    def __init__(self, src_ip, dest_ip, protocol, port):
        self.src_ip = src_ip
        self.dest_ip = dest_ip
        self.protocol = protocol
        self.port = port


# Step 2: Firewall rules
blocked_ips = ["192.168.1.100", "10.0.0.50"]
blocked_ports = [23, 445]              # Telnet, SMB
blocked_protocols = ["FTP"]


# Step 3: Function to check a packet against rules
def filter_packet(p):
    print(f"\nChecking packet: {p.src_ip} -> {p.dest_ip} ({p.protocol}:{p.port})")

    if p.src_ip in blocked_ips:
        print(f"  Blocked: Source IP {p.src_ip} is blacklisted!")
    elif p.port in blocked_ports:
        print(f"  Blocked: Port {p.port} is restricted!")
    elif p.protocol in blocked_protocols:
        print(f"  Blocked: Protocol {p.protocol} is not allowed!")
    else:
        print("  Allowed: Packet passed the firewall.")


# Step 4: Main
print("Firewall Simulation Started...")

# Step 5: Simulated packets
traffic = [
    Packet("192.168.1.10",  "8.8.8.8", "HTTP", 80),
    Packet("192.168.1.100", "8.8.8.8", "HTTP", 80),
    Packet("10.0.0.20",     "8.8.4.4", "FTP",  21),
    Packet("172.16.0.5",    "8.8.8.8", "SSH",  22),
    Packet("192.168.1.15",  "8.8.8.8", "SMB",  445),
]

# Step 6: Check each packet
for p in traffic:
    filter_packet(p)

print("\nFirewall Simulation Completed.")
