import random
from math import gcd

def is_prime(n, k=20):
    if n < 2: return False
    if n % 2 == 0: return n == 2
    d, r = n - 1, 0
    while d % 2 == 0: d //= 2; r += 1
    for _ in range(k):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1: break
        else: return False
    return True

def gen_prime(bits):
    while True:
        p = random.getrandbits(bits) | (1 << (bits - 1)) | 1
        if is_prime(p): return p

# ---- RSA ----
p, q = gen_prime(256), gen_prime(256)          # two 256-bit primes
n    = p * q                                    # modulus (512 bits)
phi  = (p - 1) * (q - 1)                        # totient
e    = 65537                                    # public exponent
d    = pow(e, -1, phi)                          # private exponent

msg = int(input("Enter message (as number): "))
C   = pow(msg, e, n)                            # encrypt
print("Encrypted:", C)
print("Decrypted:", pow(C, d, n))               # decrypt
