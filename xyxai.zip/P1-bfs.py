import queue as Q
from RMP import dict_gn

start = 'Arad'
goal = 'Bucharest'

def BFS(start, goal):
    cityq = Q.Queue()
    visitedq = Q.Queue()
    parent = {start: None}   # to reconstruct the path
    traversal = []           # order of visited cities

    cityq.put(start)
    visitedq.put(start)

    while not cityq.empty():
        city = cityq.get()
        traversal.append(city)

        if city == goal:
            # Reconstruct path from goal back to start
            path = []
            while city is not None:
                path.append(city)
                city = parent[city]
            path.reverse()
            return traversal, path

        for eachcity in dict_gn[city].keys():
            if eachcity not in visitedq.queue:
                visitedq.put(eachcity)
                parent[eachcity] = city
                cityq.put(eachcity)

    return traversal, None

def main():
    traversal, path = BFS(start, goal)

    print("BFS Traversal from", start, "to", goal, "is:")
    print(" -> ".join(traversal))
    print()
    print("Shortest Path (BFS) from", start, "to", goal, "is:")
    print(" -> ".join(path))

main()
