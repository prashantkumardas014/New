from RMP import dict_gn
from RMP import dict_hn

start = 'Arad'
goal = 'Bucharest'

def rbfs(city, path, g, f_limit):
    # Goal test
    if city == goal:
        return path, g

    successors = []

    # Generate successors
    for next_city in dict_gn[city]:
        if next_city not in path:
            new_g = g + dict_gn[city][next_city]
            h = dict_hn[next_city]
            # f(n) = g(n) + h(n)
            f = new_g + h
            successors.append([next_city, new_g, f])

    # If there are no successors
    if len(successors) == 0:
        return None, float('inf')

    while True:
        # Sort according to f value
        successors.sort(key=lambda x: x[2])

        # Best successor
        best = successors[0]
        # If best exceeds the limit, backtrack
        if best[2] > f_limit:
            return None, best[2]
        # Find the alternative path
        if len(successors) > 1:
            alternative = successors[1][2]
        else:
            alternative = float('inf')

        # Recursive call
        result, best_f = rbfs(
            best[0],
            path + [best[0]],
            best[1],
            min(f_limit, alternative)
        )

        # If solution is found
        if result is not None:
            return result, best_f

        # Update f value after backtracking
        best[2] = best_f

def main():
    path, total_cost = rbfs(
        start,
        [start],
        0,
        float('inf')
    )
    if path:
        print("The RBFS path with the total cost is:")
        print(" -> ".join(path))
        print("Total cost:", total_cost)
    else:
        print("No path found.")

main()
