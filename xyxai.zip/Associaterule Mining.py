
from mlxtend.frequent_patterns import apriori, association_rules
import pandas as pd

dataset = [
    ['milk', 'bread', 'nuts'],
    ['milk', 'bread'],
    ['milk', 'eggs', 'nuts'],
    ['milk', 'bread', 'eggs'],
    ['bread', 'nuts']
]

df = pd.DataFrame(dataset)

df_encoded = pd.get_dummies(df, prefix_sep='')

frequent_itemsets = apriori(
    df_encoded,
    min_support=0.5,
    use_colnames=True
)


print("Frequent Itemsets:")
print(frequent_itemsets)


rules = association_rules(
    frequent_itemsets,
    metric="confidence",
    min_threshold=0.7
)


print("\nAssociation Rules:")
print(rules[['antecedents', 'consequents', 'support', 'confidence']])
