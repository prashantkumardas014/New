from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.get("file:///C:/Users/ASUS/OneDrive/Desktop/cis/ONEDay/practht09.html")


links = driver.find_elements(By.TAG_NAME, "a")
images = driver.find_elements(By.TAG_NAME, "img")
buttons = driver.find_elements(By.TAG_NAME, "button")
inputs = driver.find_elements(By.TAG_NAME, "input")

print("===== Object Count =====")
print("Links   :", len(links))
print("Images  :", len(images))
print("Buttons :", len(buttons))
print("Inputs  :", len(inputs))
print("=======================")

driver.quit()