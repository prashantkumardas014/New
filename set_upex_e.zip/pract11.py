from selenium import webdriver
from selenium.webdriver.common.by import By
from openpyxl import load_workbook

driver = webdriver.Chrome()

driver.get("file:///C:/Users/ASUS/OneDrive/Desktop/cis/ONEDay/practht11.html")

workbook = load_workbook("students.xlsx")
sheet = workbook.active

for row in range(2, 12):

    roll = sheet.cell(row, 1).value
    name = sheet.cell(row, 2).value
    marks = sheet.cell(row, 3).value

    driver.find_element(By.ID, "roll").clear()
    driver.find_element(By.ID, "roll").send_keys(str(roll))

    driver.find_element(By.ID, "name").clear()
    driver.find_element(By.ID, "name").send_keys(name)

    driver.find_element(By.ID, "marks").clear()
    driver.find_element(By.ID, "marks").send_keys(str(marks))

    driver.find_element(By.TAG_NAME, "button").click()

    result = driver.find_element(By.ID, "result").text

    print(result)

    if name in result and str(marks) in result:
        sheet.cell(row, 4).value = "Verified"
    else:
        sheet.cell(row, 4).value = "Failed"

workbook.save("students.xlsx")

driver.quit()

print("All 10 student records processed.")